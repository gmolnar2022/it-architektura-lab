# IT Architektúra – gyakorlati munkafüzet

